﻿#nullable enable
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using GeoJsonWeather.Api;
using GeoJsonWeather.Models;
using GeoJsonWeather.Parsers;

namespace GeoJsonWeather;

public class ObservationManager
{
    public static async IAsyncEnumerable<ObservationModel?> GetNearestObservations(
        double latitude,
        double longitude,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        var pointsUrl = $"https://api.weather.gov/points/{latitude},{longitude}";

        var pointsMgr = new ApiManager(new ApiFetcher(string.Empty, pointsUrl));
        ForecastPointModel? point = await pointsMgr.GetModelAsync(new ForecastPointParser(), ct);
        if (point is null || string.IsNullOrWhiteSpace(point.ZoneUrl))
            yield break;

        var zoneMgr = new ApiManager(new ApiFetcher(string.Empty, point.ZoneUrl));
        ForecastZoneModel? zone = await zoneMgr.GetModelAsync(new ForecastZoneParser(), ct);
        if (zone?.ObservationStationUrls is null || zone.ObservationStationUrls.Count == 0)
            yield break;

        var stations = new List<ObservationStationModel>();

        // Keep sequential for now (simple + safe). We can parallelize later with a cap.
        foreach (string stationUrl in zone.ObservationStationUrls)
        {
            ct.ThrowIfCancellationRequested();

            var stationMgr = new ApiManager(new ApiFetcher(string.Empty, stationUrl));
            ObservationStationModel? station = await stationMgr.GetModelAsync(new ObservationStationParser(), ct);
            if (station != null) stations.Add(station);
        }

        if (stations.Count == 0)
            yield break;

        // Loop while inside zone polygon
        while (!ct.IsCancellationRequested &&
               GeoHelper.IsPointInPolygon(latitude, longitude, zone.ZonePolygonCoordinates))
        {
            ObservationStationModel nearest = FindNearestStation(latitude, longitude, stations);
            var obsUrl = $"https://api.weather.gov/stations/{nearest.StationIdentifier}/observations/latest";

            ObservationModel? obs = null;
            try
            {
                var obsMgr = new ApiManager(new ApiFetcher(string.Empty, obsUrl));
                obs = await obsMgr.GetModelAsync(new ObservationParser(), ct);
            }
            catch
            {
                // Bulletproof behavior: don't crash the stream loop.
                // Later we’ll add “last known good” + stale flag.
            }

            yield return obs;

            // Delay AFTER yielding so you get an immediate first update.
            await Task.Delay(60000, ct);
        }
    }

    private static ObservationStationModel FindNearestStation(
        double targetLatitude,
        double targetLongitude,
        List<ObservationStationModel> stations)
    {
        string? nearestStationId = null;
        var minDistance = double.MaxValue;

        foreach (ObservationStationModel station in stations)
        {
            double distance = GeoHelper.CalculateHaversineDistance(
                targetLatitude, targetLongitude,
                station.Coordinates.Latitude, station.Coordinates.Longitude);

            if (!(distance < minDistance)) continue;
            minDistance = distance;
            nearestStationId = station.Id;
        }

        return stations.First(x => x.Id == nearestStationId);
    }
}