﻿namespace ThunderApp.Models;


public readonly record struct GeoPoint(double Lat, double Lon);