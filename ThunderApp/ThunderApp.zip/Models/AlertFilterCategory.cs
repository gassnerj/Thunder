﻿namespace ThunderApp.Models;

/*public enum AlertCategory
{
    ShortFused,
    LongFused,
    Winter,
    Fire,
    Wind,
    Hydrology,
    Heat,
    Fog,
    Marine,
    Other
}

public enum AlertLifecycle
{
    Warning,
    Watch,
    Advisory,
    Statement,
    Other
}*/