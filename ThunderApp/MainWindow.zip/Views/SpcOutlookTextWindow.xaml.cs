using System.Windows;

namespace ThunderApp.Views;

public partial class SpcOutlookTextWindow : Window
{
    public SpcOutlookTextWindow()
    {
        InitializeComponent();
    }
}
