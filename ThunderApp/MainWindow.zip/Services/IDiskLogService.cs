﻿namespace ThunderApp.Services;

public interface IDiskLogService
{
    void Log(string message);
}