﻿namespace ThunderApp.Models;

public enum AlertCategory
{
    Severe,
    Fire,
    Winter,
    Hydrology,
    Wind,
    Marine,
    Heat,
    Fog,
    Tropical,
    Other
}